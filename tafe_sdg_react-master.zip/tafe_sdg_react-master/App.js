import React from 'react'
import Navigator from './src/routes/Navigator'

const App = () => {
  return(
    <>
    <Navigator />

    </>
  )
}
export default App;